inp=open('F:\LAB-05\input2.txt')
inp2=inp.readline()
inp2=inp2.split()
m=int(inp2[0]) #m=5
n=int(inp2[1]) #n=2
#print(inp2)
out=open('F:\LAB-05\output2.txt','w')
start_time=[]
ending_time=[]

for i in range(m):
    i=inp.readline()
    i=i.split()
    start_time.append(int(i[0]))
    ending_time.append(int(i[1]))

def Assignment_Selection(start_time,ending_time):
    selected=[]
    for i in range(len(ending_time)):
        for j in range (i+1,len(ending_time)):
            if ending_time[i]>ending_time[j]:
                temp=ending_time[i]
                ending_time[i]=ending_time[j]
                ending_time[j]=temp
                tmp=start_time[i]
                start_time[i]=start_time[j]
                start_time[j]=tmp
    print('start time: ',start_time)
    print('finish time: ',ending_time)
    selected.append(start_time[0])
    selected.append(ending_time[0])
    count=1
    f=ending_time[0]
    if m<n:
        count=m
    else:
        count=n
    if m>n:    
        for i in range(n):
            f=ending_time[i]
            for j in range(m):
                if start_time[j]>=f:
                    count+=1
                    f=ending_time[j]                     
    #print('total number of activities: ',count)
    out.write('total number of activities: '+' '+str(count))
Assignment_Selection(start_time,ending_time)

