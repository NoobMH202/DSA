import math
inp=open('F:\LAB-05\input4.txt')
inp=inp.readlines()
out=open('F:\LAB-05\output4.txt','w')
a=(inp[0])
a=a.split()
#print(a) #['1', '4']

b=(inp[1])
b=b.split()
#print(b) #['1', '10']

c=int(a[0])
d=int(a[1])

x=int(b[0])
y=int(b[1])

count=0
for i in inp:
    if a==0 and b==0:
        break
for i in range(c,(int)(math.sqrt(d))+1):
    count+=1
out.write(str(count)+'\n')
#print(count)

count=0
for i in range(x,(int)(math.sqrt(y))+1):
    count+=1
out.write(str(count))
#print(count)









