x=open('F:\LAB-05\input3.txt')
inp=int(x.readline())
inp2=x.readline()
inp2=inp2.split()
out=open('F:\LAB-05\output3.txt','w')
characters = x.readline()
#print(characters)
activity=[]

for i in range(inp):
    activity.append(int(inp2[i]))
    
for i in range(inp):
    for j in range(i+1, inp):
        if (activity[i]>activity[j]):
            tmp=activity[i]
            activity[i]=activity[j]
            activity[j]=tmp
#print('sorted: ',activity)

stack =[]
sequence=[]
idx=0
jack_hours=0
jil_hours=0

for c in characters:
    if c == "J":
        stack.append(activity[idx])
        sequence.append(activity[idx])
        jack_hours+=activity[idx]
        idx+=1
    
    elif c == "j": 
        a = stack.pop()
        sequence.append(a)
        jil_hours+=a

out.write('sequence: '+str(sequence)+'\n')
out.write('Jack will work for '+str(jack_hours)+' hours'+'\n')
out.write('Jill will work for '+str(jil_hours)+' hours')            
#print('sequence:',sequence)
#print('Jack will work for',jack_hours,'hours')
#print('Jill will work for',jil_hours,'hours')


