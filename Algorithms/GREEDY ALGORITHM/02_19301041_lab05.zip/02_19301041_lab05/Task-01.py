inp=open('F:\LAB-05\input1.txt')
#inp=inp.read()
#print(inp)
inp2=int(inp.readline())
#print(inp2)
out=open('F:\LAB-05\output1.txt','w')
start_time=[]
ending_time=[]

for i in range(inp2):
    i=inp.readline()
    i=i.split()
    start_time.append(int(i[0]))
    ending_time.append(int(i[1]))

def Assignment_Selection(start_time,ending_time):
    selected=[]
    for i in range(len(ending_time)):
        for j in range (i+1,len(ending_time)):
            if ending_time[i]>ending_time[j]:
                temp=ending_time[i]
                ending_time[i]=ending_time[j]
                ending_time[j]=temp
                tmp=start_time[i]
                start_time[i]=start_time[j]
                start_time[j]=tmp
    #print(start_time)
    #print(ending_time)
    selected.append(start_time[0])
    selected.append(ending_time[0])
    count=1
    f=ending_time[0]
    for i in range(1,inp2):
        if start_time[i]>=f:
            count+=1
            f=ending_time[i]
            selected.append(start_time[i])
            selected.append(ending_time[i])
    #print(count)
    out.write(str(count)+'\n')
    #print(selected)
    position=[]
    position.append(selected[0::2])
    position.append(selected[1::2])
    for i in range(count):
        out.write(str(position[0][i])+' '+str(position[1][i])+'\n')
        #print(position[0][i]," ",position[1][i])

Assignment_Selection(start_time,ending_time)



















