inp=open("F:\LAB-03\input1.txt")
inp=inp.read()
inp=inp.splitlines()
out=open("F:\LAB-03\output2.txt","w")
x=inp[0]
y=inp[1:]

graph={}
for i in y:
    adj= i.split()
    graph[adj[0]]=adj[1:]
    
visited=[0]*12
queue=[]
def BFS(visited,graph,st_node,end_node):
    visited[int(st_node)-1]=1
    queue.append(st_node)
    while queue is not None:
        m=queue.pop(0)
        out.write(m+' ')
        if m==end_node:
            break
        for neighbour in graph[m]:
            if visited[int(neighbour)-1]==0:
                visited[int(neighbour)-1]=1
                queue.append(neighbour)
    
BFS(visited,graph,'1','12')
