inp=open("F:\LAB-03\input4.txt")
inp=inp.read()
inp=inp.splitlines()
out=open("F:\LAB-03\output4.txt","w")

graph_koyta=inp[0]
first_graph=inp[2:4]
second_graph=inp[5:]

graph1={}
graph2={}

for i in first_graph:
    adj=i.split()
    p=int(adj[0])
    value=int(adj[1])
    if p not in graph1.keys():
        graph1[p]=list()
    graph1[p].append(value)
    if value not in graph1.keys():
        graph1[value]=list()
    graph1[value].append(p)
#print(graph1)

for i in second_graph:
    adj=i.split()
    p=int(adj[0])
    value=int(adj[1])
    if p not in graph2.keys():
        graph2[p]=list()
    graph2[p].append(value)
    if value not in graph2.keys():
        graph2[value]=list()
    graph2[value].append(p)
#print(graph2)

visited=[0]*12
queue=[]
discovery_time=[0]*12
def BFS(visited,graph1,st_node,end_node):
    visited[int(st_node)-1]=1
    queue.append(st_node)
    while len(queue)!=0:
        m=queue.pop(0)
        for neighbour in graph1[m]:
            if visited[int(neighbour)-1]==0:
                visited[int(neighbour)-1]=1
                queue.append(int(neighbour))
                discovery_time[int(neighbour)-1]=discovery_time[m-1]+1
    #print('discovery time: '+str(discovery_time[int(end_node)-1])+'\n')  
    out.write('discovery time: '+str(discovery_time[int(end_node)-1])+"\n")
BFS(visited,graph1,1,3)
visited=[0]*12
queue=[]
discovery_time=[0]*12
BFS(visited,graph2,1,4)