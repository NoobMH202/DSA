inp=open("F:\LAB-03\input1.txt")
inp=inp.read()
inp=inp.splitlines()
out=open("F:\LAB-03\output3.txt","w")
x=inp[0]
y=inp[1:]

graph={}
for i in y:
    adj= i.split()
    graph[adj[0]]=adj[1:]
    
visited=[0]*12
printed=[]

def DFS_VISIT(graph,node):   
    visited[int(node)-1]=1
    printed.append(node)
    for node in graph[node]:  
        if node is not visited:
            DFS_VISIT(graph,node)
            
def DFS(graph,end_point): 
    for node in graph:  
        if node is not visited:
            DFS_VISIT(graph,node)
   
DFS_VISIT(graph,'1')
for i in printed:
    out.write(i+' ')
    if i=='12':
        break
    



