inp=open("F:\LAB-03\input1.txt")
inp=inp.read()
inp=inp.splitlines()
out=open("F:\LAB-03\output1.txt","w")

x=inp[0]
y=inp[1:]

graph={}

for i in y:
    adj= i.split()
    graph[adj[0]]=adj[1:]    
for key,value in graph.items():
    out.write(str(key)+"->"+str(value)+'\n')  