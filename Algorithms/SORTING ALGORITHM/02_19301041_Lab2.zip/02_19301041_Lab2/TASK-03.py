inp=open("F:\LAB-02\input3.txt")
inp = inp.read()
out=open("F:\LAB-02\output3.txt","w")
n=inp.split()
student = int(n[0])
marks=[]
s_id=[]

for i in range(1,student+1):
    s_id.append(n[i])
    
for j in range(student+1,len(n)):
    marks.append(n[j])

def insertionSort(student,s_id,marks): 
    for i in range(1,student):
        nums=marks[i]
        id=s_id[i]
        cnt = i-1     
        while cnt>=0 and int(marks[cnt])>int(nums):
            marks[cnt+1]=marks[cnt]
            s_id[cnt+1]=s_id[cnt]
            cnt-=1       
        marks[cnt+1]=nums
        s_id[cnt+1]=id
        i+=1
    for j in range(-1,-len(s_id)-1,-1):
        out.write(s_id[j])
        out.write(" ")
insertionSort(student,s_id,marks)

