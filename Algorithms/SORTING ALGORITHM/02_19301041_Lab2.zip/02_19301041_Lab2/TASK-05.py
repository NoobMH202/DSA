def partition(a,p,q):
    x=a[p]
    i=p
    for j in range(p+1,q):
        if a[j]<=x:
            i+=1
            a[i],a[j]=a[j],a[i]
    a[p],a[i]=a[i],a[p]
    return i



def quickSort(a,p,r):
    if p is not r:
        q=partition(a,p,r)
        quickSort(a,p,q-1)
        quickSort(a,q+1,r)
        
def findK(a, p, r, k):

    if (k > 0 and k <= r - p + 1):
        pos = partition(a, p, r)
        if (pos - p == k - 1):
            return a[pos]
        if (pos - p > k - 1):
            return findK(a, p, pos - 1, k)

        return findK(a, pos + 1, r, k - pos + p - 1)

