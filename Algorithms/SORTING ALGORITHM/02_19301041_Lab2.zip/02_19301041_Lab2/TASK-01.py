inp=open("F:\LAB-02\input1.txt")
inp=inp.read()
n=inp.split()
z=int(n[0])
arr=n[1:]
out=open("F:\LAB-02\output1.txt",'w')

lst=[]
for i in arr:
    lst.append(int(i))

def bubbleSort(lst):
    for i in range(len(lst)-1):
        for j in range(len(lst)-i-1):
            if sorted(lst)==lst:
                break
            elif lst[j]>lst[j+1]:
                temp=lst[j]
                lst[j]=lst[j+1]
                lst[j+1]=temp
    out.write(str(lst))
bubbleSort(lst)

