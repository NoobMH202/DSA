inp=open("F:\LAB-02\input4.txt")
n=int(inp.readline())
x=inp.readline().split()
x=[int(i) for i in x]
out=open("F:\LAB-02\output4.txt","w")

def merge(values):
    if len(values) == 1:
        return values
    else:
        mid= int(len(values)/2)
        a1 = merge(values[:mid])
        a2 = merge(values[mid:])
        a3 = []
        cnt1 = 0
        cnt2 = 0
        

        i=0
        while i<=len(values):
            if (a1[cnt1]<a2[cnt2]):
                a3.append(a1[cnt1])
                cnt1+=1
            elif (a1[cnt1]>a2[cnt2]):

                a3.append(a2[cnt2])
                cnt2+=1

            else:
                a3.append(a1[cnt1])
                cnt1+=1
                a3.append(a2[cnt2])
                cnt2+=1
                
            if (cnt1>=len(a1)):
                a3+=a2[cnt2:]
                break
            elif ( cnt2 >= len(a2)):
                a3+=a1[cnt1:]
                break
        i+=1
        return a3

elem = merge(x)
for i in elem:
    out.write(str(i)+ " ")

