inp=open("F:\LAB-02\input2.txt")
inp=inp.read()
out=open("F:\LAB-02\output2.txt","w")

n=inp.split()
z=int(n[0])
N=int(n[1])
arr=(n[2:])
lst=[]
for i in arr:
    lst.append(int(i))


def sort(lst,N):
    for i in range(0,len(lst)-1):
        min_position=i
       
        for j in range (i+1,len(lst)):
            if lst[j]<lst[min_position]:
                min_position=j
                
        temp=lst[i]
        lst[i]=lst[min_position]
        lst[min_position]=temp

    for k in lst:
        return lst[0:N]
    #out.write(str(lst[i])+" ")
  
#print(sort(lst,N))
sort(lst,N)

for i in range(0,N):
    
    out.write(str(lst[i])+" ")



