inp=open('F:\LAB-06\input2.txt')
inp=inp.read()
i=inp.split()
out=open('F:\LAB-06\output2.txt','w')
zone_number=i[0]
actual_zone_sequence=i[1]
predicted_zone=i[2]
#print(zone_number,predicted_zone,actual_zone_sequence)

g={"Y": "Yasnaya","R":"Rozhok",
   "S":"School","P":"Pochinki",
   "F":"Farm","M":"Mylta",
   "H":"Shelter","I":"Prison"}

arr1=[]
arr1.append(None)
arr2=[]
arr2.append(None)

for i in actual_zone_sequence:
    arr1.append(i)
for i in predicted_zone:
    arr2.append(i)

def LCS(X,Y):
    m=len(X)
    n=len(Y)
    c=[[0]*(m) for i in range(m)]
    t=[[0]*(n) for j in range(n)]
    
    for i in range(1,m): 
        c[i][0] = 0 
        t[i][0] = None      
    for j in range(1,n): 
        c[0][j] = 0 
        t[0][j] = None 
    for i in range(1,n):
        for j in range(1,m):
            if X[j]==Y[i]:
                c[j][i]=c[j-1][i-1]+1
                t[j][i]="diagonal"             
            elif c[j][i-1]>=c[j-1][i]:
                c[j][i]=c[j][i-1]
                t[j][i]="up"
            else:
                c[j][i]=c[j-1][i]
                t[j][i]="left"
                
    longest_common_zone_sequence=[]
    p=m-1
    k=n-1
    while k != 0 or p != 0:
        if t[p][k]=="diagonal":
            longest_common_zone_sequence.append(X[p])
            k-=1
            p-=1
        elif t[p][k]=="up":
            k-=1
        else:
            t[p][k]=="left"
            p-=1
    for i in reversed(longest_common_zone_sequence):
        out.write(str(g[i])+' ')
        #print(g[i],end=" ") 
    Correctness=(len(longest_common_zone_sequence)*100)//(m-1)
    #print()
    #print('Correctness of Prediction:',Correctness,'%')
    out.write('\n')
    out.write('Correctness of Prediction: '+str(Correctness)+'%')
LCS(arr1,arr2)