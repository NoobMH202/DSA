inp=input("enter input: ")
print(inp)
j=int(inp)
count=1
while j!=0:
  idx=[int(a) for a in str(j)]
  new=int(j) - max(idx)
  count+=1
  print(new)
  j=new
print("minimum",count, "steps will require")