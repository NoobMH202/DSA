#Task-01

x=open('F:\LAB-01\LAb1input.txt')
x=x.read()
file=open('F:\LAB-01\LAb1output.txt','w')
record=open('F:\LAB-01\LAb1record.txt','w')

odd_parity_count=0
even_parity_count=0
no_parity_count=0
palindrome1=0
non_palindrome1=0

split_koro=x.split('\n')
for i in split_koro:
    i=i.split(' ')

    if '.' not in i[0]:
        if int(i[0])%2==0:
            even_parity_count+=1
            file.write(i[0]+' has even parity and ')
        else:
            odd_parity_count+=1
            file.write(i[0]+' has odd parity and ')
    else:
        no_parity_count+=1
        file.write(i[0]+' has no parity and ')
    
    def palindrome(x,y):
        global palindrome1
        global non_palindrome1
        if x is None:
            non_palindrome1+=1
            file.write(x+' is not a palindrome'+'\n')
            return

        for i in range(0,y//2):
            if x[i]!=x[y-1-i]:
                non_palindrome1+=1
                file.write(x+' is not a palindrome'+'\n')
                return
            
        palindrome1+=1
        file.write(x+' is a palindrome'+'\n')
        return
    
    y=len(i[1])
    palindrome(i[1], y)

record.write('percentage of odd parity: '+str((odd_parity_count/5)*100)+'%'+'\n')
record.write('percentage of even parity: '+str((even_parity_count/5)*100)+'%'+'\n')
record.write('percentage of no parity: '+str((no_parity_count/5)*100)+'%'+'\n')
record.write('percentage of palindrome: '+str((palindrome1/5)*100)+'%'+'\n')
record.write('percentage of non-palindrome: '+str((non_palindrome1/5)*100)+'%'+'\n')

