#Task-04

inpu=open('F:\LAB-01\LAb4input.txt')
n=inpu.read().splitlines()
z=int(n[0])

output=open('F:\LAB-01\LAb4output.txt','w')


A=[]
B=[]
C=[[0]*z for i in range (z)]

for i in range(z):
    A.append(n[i+1].split())
    B.append(n[i+1+z].split())

for i in range (z):
    for j in range(z):
        for k in range(z):
            C[i][j]+=int(A[i][k])*int(B[k][j])

for i in C:
    for j in i:
        output.write(f"{j} ")
    output.write('\n')

