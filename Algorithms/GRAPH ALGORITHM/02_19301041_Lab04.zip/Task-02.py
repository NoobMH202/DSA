inp=open('F:\LAB-04\input1.txt')
inp2=int(inp.readline())
print('test cases are:',inp2)
out=open('F:\LAB-04\output2.txt','w')

from queue import PriorityQueue
import math

def dijkstra(graph, source):
    distance = [math.inf]*len(graph)
    distance[source] = 0
    queue = PriorityQueue()
    visited = [0]*len(graph)
    queue.put((distance[source], source))
    path=[0]*len(graph)
    path[source]=source
      
    while not queue.empty():
        u = queue.get()[1]
        if (visited[u]):
            continue
        visited[u] = True
        for neighbour in graph[u]:
            alt = distance[u] + neighbour[1]
            #print(alt,end=' ')
            if alt < distance[neighbour[0]]:
                distance[neighbour[0]] = alt
                path[neighbour[0]] = u
                queue.put((distance[neighbour[0]], neighbour[0]))
    #return distance[len(graph)-1]
    return path

for i in range(inp2):
    inp3=inp.readline()
    inp3=inp3.split()
    a= int(inp3[0])
    b= int(inp3[1])
    graph = [[] for i in range(1+a)]

    for j in range(b):
        inp3=inp.readline()
        inp3=inp3.split()
        x=int(inp3[0])
        #print(a)
        y=int(inp3[1])
        #print(b)
        z=int(inp3[2])
        #print(c)
        vertices = y
        graph[x].append((y, z))
        graph[y].append((x, z))
    #NEW_GRAPH.append(dijkstra(graph, 1))
    #print(len(NEW_GRAPH))
    NEW_GRAPH=dijkstra(graph, 1)
    output=[]
    for cnt in range(1,len(NEW_GRAPH)):
        if (NEW_GRAPH[cnt] not in output):
            output.append(NEW_GRAPH[cnt])

    if b>0:
        output.append(vertices)
        for cnt2 in range(len(output)):
            #print(str(output[cnt2]),end=' ')
            out.write(str(output[cnt2]))
        #print()
        out.write('\n')
    else:
        #print(output[0],end=' ')
        #print()
        out.write(str(output[0]))
        out.write('\n')