inp=open('F:\LAB-04\input5.txt')
inp=inp.read()
inp=inp.splitlines()
print(inp)
T=inp[0]
print('number of test case: ',T)
out=open('F:\LAB-04\output5.txt','w')

import math
import heapq
infinity=-math.inf
def network(graph,source):
    queue = []
    dist = [infinity]*(len(graph)+1)
    dist[source] = 0
    visited = [0]*(len(graph)+1)
    prev = [None]*(len(graph)+1)
    prev[source] = 0
    
    for v in graph:
        heapq.heappush(queue,(dist[v],v))
    heapq._heapify_max(queue)

    while len(queue)!=0:
        w,u = heapq._heappop_max(queue)

        if visited[u]:
            continue
        visited[u] = True

        for neighbour in graph[u]:
            if w == 0 and neighbour[1]!=0:
                alt = neighbour[1]
            else:
                alt = min(w,neighbour[1])
            if alt>dist[neighbour[0]]:
                dist[neighbour[0]] = alt
                prev[neighbour[0]] = u
                heapq.heappush(queue,(dist[neighbour[0]],neighbour[0]))
                heapq._heapify_max(queue)

    for i in dist[1:]:
        if i==infinity:
            i = -1
        #print(i,end=' ')
        out.write(str(i)+' ')
    out.write("\n")
    #print()

def cholo_graph_banai(inp):
    graph={}
    for k in inp:
        k = k.split(" ")
        try:
            graph[int(k[0])].append((int(k[1]),int(k[2])))
        except:
            graph[int(k[0])] = [(int(k[1]),int(k[2]))]   
        if int(k[1]) not in graph:
            graph[int(k[1])]=[] 
    return graph

cnt = 1
for i in range(int(inp[0])):
    a = int(inp[cnt].split()[1])
    if a==0:
        graph= {int(inp[cnt].split()[0]):[]}
    else:
        tmp = inp[cnt+1:cnt+1+a]
        graph = cholo_graph_banai(tmp)
    network(graph,int(inp[cnt+1+a]))  
    cnt+=2+a