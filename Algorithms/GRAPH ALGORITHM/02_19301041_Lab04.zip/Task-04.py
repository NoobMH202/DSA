#MOTIJHEEL Denoted as M
#MOGHBAZAR Denoted as N

inp=open('F:\LAB-04\input4.txt')
inp2=inp.read()
inp2=inp2.splitlines()
#print(inp2)
out=open('F:\LAB-04\output4.txt','w')

graph={}
for i in inp2:
    adj= i.split()
    graph[adj[0]]=adj[1:]  
print(graph)
#a=graph.keys()
#print(a)
#print(len(graph))

import math
from queue import PriorityQueue
def dijkstra(graph,source):
    vertex = [math.inf]*len(graph)
    vertex[source] = 0
    queue = PriorityQueue()
    visited = [0]*len(graph)
    #print(visited)
    queue.put((vertex[source], source))
      
    while not queue.empty():
        u = queue.get()[1]
        if (visited[u]):
            continue
        visited[u] = True
        for neighbour in graph[u]:
            alt = vertex[u] + neighbour[1]
            #print(alt,end=' ')
            if alt < vertex[neighbour[0]]:
                vertex[neighbour[0]] = alt
                queue.put((vertex[neighbour[0]], neighbour[0]))
    return vertex[len(graph)-1]
#print(dijkstra(graph,'M'))
#
'''we have to implement a 
condition in code---if we are able to
find the node of MOGHBAZAR(N) we will break the condition.
moreover, we have to check with other corresponding nodes
which gives the shortest summation of weights toward (N).
from simulation the output should be:
    MOTIJHEEL(M) A B G F MOGHBAZAR(N)'''

'''for this task BFS also gives the 
shortest path between source and destination.But we couldn't 
use BFS for this particular task as we have
to consider weights for this task. we know dijkstra will
only work as bfs when all the weights of edges are similar.'''



